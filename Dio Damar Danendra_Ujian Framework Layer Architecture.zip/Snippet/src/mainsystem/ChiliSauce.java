package mainsystem;

public class ChiliSauce extends Topping implements Burger {

	Burger newBurger;
	String id;
	
	public ChiliSauce(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Chili Sauce...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", chili sauce";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 5000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

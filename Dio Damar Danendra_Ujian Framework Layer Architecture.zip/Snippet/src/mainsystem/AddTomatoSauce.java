package mainsystem;

public class AddTomatoSauce implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Tomato Sauce" && request.getTopping() == "MincedBeef") {
			Burger newBurger = new TomatoSauce(new Lettuce(new MincedBeef(new BurgerBun())));
		}
		
		else if (request.getTopping() == "Tomato" && request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new TomatoSauce(new Lettuce(new ChickenBurgerPatty(new BurgerBun())));
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

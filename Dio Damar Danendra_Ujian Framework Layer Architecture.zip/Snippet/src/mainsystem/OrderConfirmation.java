package mainsystem;

import java.util.Scanner;
import java.util.Vector;

public class OrderConfirmation implements PaymentState {

	Transaction newTransaction;
	String name, menu, email, choice;
	Scanner input = new Scanner(System.in);
	Vector<Customer> customer = new Vector<>();
	
	public OrderConfirmation() {
		System.out.println("Confirm order? [Yes / No]: ");
		choice = input.nextLine();
		if (choice == "true") {
			System.out.println("Wait for your order...");
		}
		else {
			newTransaction.setCurrentPaymentState(new PaymentInformationInput());
		}
	}

	@Override
	public void changePaymentState(Transaction t) {
		System.out.println("This is the End of your Transaction");
	}

}

package mainsystem;

public interface PaymentState {
	public abstract void changePaymentState(Transaction t);
}

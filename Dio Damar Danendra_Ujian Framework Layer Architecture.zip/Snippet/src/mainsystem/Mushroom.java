package mainsystem;

public class Mushroom extends Topping implements Burger {
	Burger newBurger;
	String id;
	
	public Mushroom(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Mushroom...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", mushroom";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 2500;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

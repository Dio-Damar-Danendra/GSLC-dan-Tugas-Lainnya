package mainsystem;

public class AddLettuce implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Lettuce" && request.getTopping() == "Cheese" && request.getTopping() == "Minced Beef") {
			Burger newBurger = new Lettuce(new MincedBeef(new Cheese(new BurgerBun())));
		}
		
		else if (request.getTopping() == "Lettuce" && request.getTopping() == "Minced Beef") {
			Burger newBurger = new Lettuce(new MincedBeef(new BurgerBun()));
		}
		
		else if(request.getTopping() == "Lettuce" && request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new Lettuce(new ChickenBurgerPatty(new BurgerBun()));
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

package mainsystem;

public class AddMincedBeef implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Minced Beef" && request.getTopping() == "Cheese") {
			Burger newBurger = new MincedBeef(new Cheese(new BurgerBun()));
		}
		
		else if (request.getTopping() == "Minced Beef") {
			Burger newBurger = new MincedBeef(new BurgerBun());
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

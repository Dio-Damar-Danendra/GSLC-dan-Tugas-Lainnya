package mainsystem;

public class Mustard extends Topping implements Burger {

	Burger newBurger;
	String id;
	
	public Mustard(Burger newBurger) {
		super(newBurger);
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", Mustard";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 4000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

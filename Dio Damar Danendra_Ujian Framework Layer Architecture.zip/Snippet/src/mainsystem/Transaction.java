package mainsystem;

public class Transaction {
	
	int id;
	private PaymentState currentPaymentState;
	
	public Transaction() {
		this.currentPaymentState = new NoTransaction();
	}

	public int getId() {
		return id;
	}

	public PaymentState getCurrentPaymentState() {
		return currentPaymentState;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCurrentPaymentState(PaymentState currentPaymentState) {
		this.currentPaymentState = currentPaymentState;
	}
	
	
}

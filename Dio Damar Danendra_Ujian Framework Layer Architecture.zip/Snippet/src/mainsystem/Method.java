package mainsystem;

public interface Method {
	public String setCurrentMethod(CookingMethod currentMethod);
}

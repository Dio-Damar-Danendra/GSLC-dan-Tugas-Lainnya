package mainsystem;
import java.util.*;

public class PaymentInformationValidation implements PaymentState {

	Transaction newTransaction;
	String name, menu, email, choice;
	Scanner input = new Scanner(System.in);
	Vector<Customer> customer = new Vector<>();
	
	public PaymentInformationValidation() {
		System.out.println("Is your data valid?");
		System.out.println("Yes / No: ");
		choice = input.next();
		input.nextLine();
		if (choice == "No") {
			newTransaction.setCurrentPaymentState(new PaymentInformationInput());
		}
		
		if(choice == "Yes") {
			newTransaction.setCurrentPaymentState(new OrderConfirmation());
		}
	}

	public Customer currentCustomer() {
		for (Customer cus : customer) {
				if(cus.getName().equalsIgnoreCase(name)) {
					return cus; 
				}
		}
		return null;
	}

	@Override
	public void changePaymentState(Transaction t) {
		// TODO Auto-generated method stub

	}

}

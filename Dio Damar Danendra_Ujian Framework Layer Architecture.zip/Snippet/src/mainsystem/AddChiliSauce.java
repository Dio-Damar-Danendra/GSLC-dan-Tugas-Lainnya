package mainsystem;

public class AddChiliSauce implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Chili Sauce") {
			Burger newBurger = new ChiliSauce(new MincedBeef(new BurgerBun()));
		
		}
		else {
			System.out.println("Invalid Input...");
		}
	}

}

package mainsystem;

public class TomatoSauce extends Sauce implements Burger {

	Burger newBurger;
	String id;
	
	public TomatoSauce(Burger burger) {
		super(burger);
		System.out.println("Adding Tomato Sauce...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", Tomato Sauce";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 7000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

package mainsystem;

public class MincedBeef extends Topping implements Burger {

	Burger newBurger;
	String id;
	
	public MincedBeef(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Minced Beef...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", minced beef";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 5000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

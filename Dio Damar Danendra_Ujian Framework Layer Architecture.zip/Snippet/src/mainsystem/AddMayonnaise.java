package mainsystem;

public class AddMayonnaise implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Mayonnaise" && request.getTopping() == "Minced Beef") {
			Burger newBurger = new Mayonnaise(new MincedBeef(new BurgerBun()));
		}
		
		else if (request.getTopping() == "Mayonnaise" && request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new MincedBeef(new BurgerBun());
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

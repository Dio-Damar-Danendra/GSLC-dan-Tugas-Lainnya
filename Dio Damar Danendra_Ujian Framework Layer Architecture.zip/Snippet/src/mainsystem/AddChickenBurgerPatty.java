package mainsystem;

public class AddChickenBurgerPatty implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new ChickenBurgerPatty(new BurgerBun());
		}
		else {
			System.out.println("Invalid Input...");
		}
	}

}

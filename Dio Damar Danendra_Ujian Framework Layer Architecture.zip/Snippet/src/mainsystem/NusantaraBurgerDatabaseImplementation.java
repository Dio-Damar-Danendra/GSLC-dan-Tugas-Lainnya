package mainsystem;

import java.util.Vector;

public class NusantaraBurgerDatabaseImplementation implements NusantaraBurgerDatabase {

	private Vector<Burger> burger = new Vector<>();
	
	public NusantaraBurgerDatabaseImplementation() {
		addBurger();
	}

	void addBurger() {
		burger.add(new ChiliSauce(new TomatoSauce(new Cucumber(new Tomato(new Lettuce(new Cheese(new MincedBeef(new BurgerBun()))))))));
		burger.add(new ChiliSauce(new TomatoSauce(new Cucumber(new Tomato(new Lettuce(new Mustard(new MincedBeef(new BurgerBun()))))))));
		burger.add(new ChiliSauce(new MushroomSauce(new Cucumber(new Tomato(new Lettuce(new ChickenBurgerPatty(new BurgerBun())))))));
		burger.add(new ChiliSauce(new CarbonaraSauce(new Cucumber(new Tomato(new Lettuce(new Mustard(new MincedBeef(new BurgerBun()))))))));
		burger.add(new CarbonaraSauce(new MushroomSauce(new Cucumber(new Tomato(new Lettuce(new Cheese(new MincedBeef(new BurgerBun()))))))));
	}
	
	@Override
	public Menu getBurger(String id) {
		for (Burger burgerList : burger) {
			if(burgerList.getId(id).equalsIgnoreCase(id)) {
				return (Menu) burgerList; 
			}
		}
		return null;
	}

}

package mainsystem;

public class Mayonnaise extends Topping implements Burger {
	
	Burger newBurger;
	String id;
	
	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", Mayonnaise";
	}


	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 20000;
	}


	public Mayonnaise(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Mayonnaise");
	}

	
	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}

}

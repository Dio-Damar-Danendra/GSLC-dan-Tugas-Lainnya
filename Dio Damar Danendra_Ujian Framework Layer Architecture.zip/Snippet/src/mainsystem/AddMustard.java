package mainsystem;

public class AddMustard implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Mustard" && request.getTopping() == "MincedBeef") {
			Burger newBurger = new Mustard(new Lettuce(new MincedBeef(new BurgerBun())));
		}
		
		else if (request.getTopping() == "Mustard" && request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new Mustard(new Lettuce(new ChickenBurgerPatty(new BurgerBun())));
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

package mainsystem;

public interface Burger {
	public String getDescription();
	
	public int getCost();

	public String getId(String id);
}

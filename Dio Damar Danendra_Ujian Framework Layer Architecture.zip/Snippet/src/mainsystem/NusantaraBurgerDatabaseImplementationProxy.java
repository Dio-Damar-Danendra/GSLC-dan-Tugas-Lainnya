package mainsystem;

import java.util.HashMap;

public class NusantaraBurgerDatabaseImplementationProxy implements NusantaraBurgerDatabase {

	HashMap<String, Menu> cache = new HashMap<>();
	NusantaraBurgerDatabase database;
	
	
	public NusantaraBurgerDatabaseImplementationProxy() {
		database = new NusantaraBurgerDatabaseImplementation();
	}


	@Override
	public Menu getBurger(String id) {
		Menu burger = cache.get(id);
		if (burger == null) {
			burger = database.getBurger(id);
			cache.put(id, burger);
		}
		
		else {
			System.out.println("Burger from Nusantara Burger's Cache: " + burger.getMenu());
		}
		
		return burger;
	}

}

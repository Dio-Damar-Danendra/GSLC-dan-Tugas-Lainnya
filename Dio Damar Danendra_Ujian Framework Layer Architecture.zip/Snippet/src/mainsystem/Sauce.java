package mainsystem;

abstract class Sauce extends Topping {

	Burger newBurger;
	
	public Sauce(Burger newBurger) {
		super(newBurger);	
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + "\n Additional Topping: ";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost();
	}

	
}

package mainsystem;

public class AddCarbonaraSauce implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Carbonara Sauce") {
			Burger newBurger = new CarbonaraSauce(new Cheese(new MincedBeef(new BurgerBun())));
		}
		else {
			System.out.println("Invalid Input...");
		}
	}

}

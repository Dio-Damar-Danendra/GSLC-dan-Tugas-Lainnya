package mainsystem;

public class Menu {
	private String id;
	private Burger menu;
	
	public Menu(String id, Burger menu) {
		this.id = id;
		this.menu = menu;
	}
	
	public String getId() {
		return id;
	}
	public Burger getMenu() {
		return menu;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setMenu(Burger menu) {
		this.menu = menu;
	}
	
	
}

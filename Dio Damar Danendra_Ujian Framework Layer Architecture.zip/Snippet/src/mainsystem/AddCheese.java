package mainsystem;

public class AddCheese implements BurgerTopping {
	
	Burger newBurger;
	
	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Cheese") {
			Burger newBurger = new Cheese(new MincedBeef(new BurgerBun()));
		}
		else {
			System.out.println("Invalid Input...");
		}
	}
}

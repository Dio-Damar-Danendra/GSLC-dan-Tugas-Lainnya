package mainsystem;

public class Customer {

	String name, menu, email;

	public Customer(String name, String menu, String email) {
		this.name = name;
		this.menu = menu;
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public String getMenu() {
		return menu;
	}

	public String getEmail() {
		return email;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}

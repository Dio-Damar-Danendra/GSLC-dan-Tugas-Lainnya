package mainsystem;

public class NoTransaction implements PaymentState {

	public NoTransaction() {
		System.out.println("No Transaction");
	}
	
	@Override
	public void changePaymentState(Transaction t) {
		t.setCurrentPaymentState(new PaymentInformationInput());

	}

}

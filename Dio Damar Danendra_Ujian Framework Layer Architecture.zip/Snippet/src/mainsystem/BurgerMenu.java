package mainsystem;

public class BurgerMenu {
	private String topping;
	private int money;
	private String id;
	Burger newBurger;
	
	public BurgerMenu(String topping, String id, int money) {
		this.topping = topping;
		this.money = money;
		this.id = id;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTopping() {
		return topping;
	}

	public int getMoney() {
		return money;
	}

	public void setTopping(String topping) {
		this.topping = topping;
	}

	public void setMoney(int money) {
		this.money = money;
	}
	
	public Burger cookBurger(Burger newBurger) {
		newBurger = this.newBurger;
		return newBurger;
	}
}

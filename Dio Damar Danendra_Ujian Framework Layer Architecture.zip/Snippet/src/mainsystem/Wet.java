package mainsystem;

public class Wet implements Method {

	CookingMethod currentMethod;
	Burger newBurger;
	
	@Override
	public String setCurrentMethod(CookingMethod currentMethod) {
		// TODO Auto-generated method stub
		return "It's a Wet-Cooked Burger.";
	}
	
	public void cookBurger(Burger newBurger) {
		newBurger = new Lettuce(new CarbonaraSauce(new Tomato(new MincedBeef(new Cheese(new BurgerBun())))));
	}

}

package mainsystem;

public interface NusantaraBurgerDatabase {
	Menu getBurger(String id);
}

package mainsystem;

public class CarbonaraSauce extends Sauce implements Burger {

	Burger newBurger;
	String id;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public CarbonaraSauce(Burger burger) {
		super(burger);
		System.out.println("Adding Carbonara Sauce...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", Carbonara Sauce";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 8000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return null;
	}
	
}

package mainsystem;

public class Dampy implements Method {

	CookingMethod currentMethod;
	Burger newBurger;
	
	@Override
	public String setCurrentMethod(CookingMethod currentMethod) {
		// TODO Auto-generated method stub
		return "It's a Dampy-Cooked Burger.";
	}
	
	public void cookBurger(Burger newBurger) {
		newBurger = new Lettuce(new CarbonaraSauce(new Tomato(new MincedBeef(new Cheese(new BurgerBun())))));
	}

}

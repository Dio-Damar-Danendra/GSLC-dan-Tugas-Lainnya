package mainsystem;

public class AddMushroomSauce implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Mushroom Sauce" && request.getTopping() == "MincedBeef") {
			Burger newBurger = new MushroomSauce(new Lettuce(new MincedBeef(new BurgerBun())));
		}
		
		else if (request.getTopping() == "Mushroom Sauce" && request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new MushroomSauce(new Lettuce(new ChickenBurgerPatty(new BurgerBun())));
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

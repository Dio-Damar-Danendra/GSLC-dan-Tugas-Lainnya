package mainsystem;

public class BurgerBun implements Burger {

	String id;

	public BurgerBun() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Sliced Burger Bun";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return 1000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}

}

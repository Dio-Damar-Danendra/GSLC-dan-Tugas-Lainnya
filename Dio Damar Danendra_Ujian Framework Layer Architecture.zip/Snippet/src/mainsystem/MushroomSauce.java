package mainsystem;

public class MushroomSauce extends Sauce implements Burger {

	Burger newBurger;
	String id;
	
	public MushroomSauce(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Mushroom Sauce...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", Mushroom Sauce";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 6500;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

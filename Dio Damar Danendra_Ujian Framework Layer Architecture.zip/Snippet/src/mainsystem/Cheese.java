package mainsystem;

public class Cheese extends Topping implements Burger {
	
	Burger newBurger;
	private String id;
	
	public Cheese(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Cheese...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", cheese";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 2000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

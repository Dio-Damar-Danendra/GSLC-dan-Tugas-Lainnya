package mainsystem;

public interface BurgerTopping {

	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping);
	
	public void addBurgerTopping(BurgerMenu request);
	
}

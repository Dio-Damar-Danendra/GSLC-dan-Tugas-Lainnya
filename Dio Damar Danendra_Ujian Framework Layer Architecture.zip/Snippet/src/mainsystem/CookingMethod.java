package mainsystem;

public class CookingMethod {
	Method currentMethod;
	Burger tempBurger;
	
	public Method getCurrentMethod() {
		return currentMethod;
	}

	public void setCurrentMethod(Method currentMethod) {
		this.currentMethod = currentMethod;
	}
	
	public void cookBurger() {
		tempBurger = new Lettuce(new CarbonaraSauce(new Tomato(new MincedBeef(new Cheese(new BurgerBun())))));
		currentMethod = getCurrentMethod();
	}
}

package mainsystem;

abstract class Topping{
	
	Burger newBurger;
	
	public Topping(Burger burger) {
		newBurger = burger;
	}
	
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription();
	}

	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost();
	}

}

package mainsystem;

public class AddTomato implements BurgerTopping {

	@Override
	public void setNextBurgerTopping(BurgerTopping nextBurgerTopping) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addBurgerTopping(BurgerMenu request) {
		if (request.getTopping() == "Tomato" && request.getTopping() == "MincedBeef") {
			Burger newBurger = new Tomato(new Lettuce(new MincedBeef(new BurgerBun())));
		}
		
		else if (request.getTopping() == "Tomato" && request.getTopping() == "Chicken Burger Patty") {
			Burger newBurger = new Tomato(new Lettuce(new ChickenBurgerPatty(new BurgerBun())));
		}
		
		else {
			System.out.println("Invalid Input...");
		}
	}

}

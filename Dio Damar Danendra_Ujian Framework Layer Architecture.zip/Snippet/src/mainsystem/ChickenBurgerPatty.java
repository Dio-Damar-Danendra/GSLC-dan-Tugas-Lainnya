package mainsystem;

public class ChickenBurgerPatty extends Topping implements Burger {

	Burger newBurger;
	String id;
	
	public ChickenBurgerPatty(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Chicken Burger Patty...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + "Chicken Patty";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 6000;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

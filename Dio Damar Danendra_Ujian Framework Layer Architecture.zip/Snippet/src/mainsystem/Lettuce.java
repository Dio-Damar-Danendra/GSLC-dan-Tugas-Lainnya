package mainsystem;

public class Lettuce extends Topping implements Burger {
	
	Burger newBurger;
	String id;
	
	public Lettuce(Burger newBurger) {
		super(newBurger);
		System.out.println("Adding Lettuce...");
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return newBurger.getDescription() + ", Lettuce";
	}

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return newBurger.getCost() + 1500;
	}

	@Override
	public String getId(String id) {
		// TODO Auto-generated method stub
		return this.id;
	}
	
}

package mainsystem;

public class Dry implements Method {

	CookingMethod currentMethod;
	Burger newBurger;
	
	@Override
	public String setCurrentMethod(CookingMethod currentMethod) {
		// TODO Auto-generated method stub
		return "It's a Dry-Cooked Burger.";
	}
	
	public void cookBurger(Burger newBurger) {
		newBurger = new Lettuce(new CarbonaraSauce(new Tomato(new MincedBeef(new Cheese(new BurgerBun())))));
	}

}

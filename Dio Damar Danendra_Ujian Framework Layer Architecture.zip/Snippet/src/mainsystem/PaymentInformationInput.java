package mainsystem;
import java.util.*;

public class PaymentInformationInput implements PaymentState {

	
	Transaction newTransaction;
	String name, menu, email;
	Scanner input = new Scanner(System.in);
	Vector<Customer> customer = new Vector<>();
	
	public PaymentInformationInput() {
		
		System.out.println("Input your information\n");
		
		do {
			System.out.println("Name: ");
			name = input.next();
		} while (name.length() < 2);
		
		do {
			System.out.println("Menu [Must contain Burger]: ");
			menu = input.next();
		} while (menu.contains("Burger"));
		
		do {
			System.out.println("E-mail: ");
			email = input.next();
		} while (email.contains("@"));
		
		customer.add(new Customer(name, menu, email));
	}
	
	@Override
	public void changePaymentState(Transaction t) {
		t.setCurrentPaymentState(new PaymentInformationValidation());
	}

}
